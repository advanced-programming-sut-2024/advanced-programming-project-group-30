package controller;

import model.Result;

public class RegisterMenuController {
    public Result register(String username, String password, String passwordConfirm, String nickname, String email) {
        return null;
    }

    public String createUniqueUserName(String DuplicateUsername) {
        return null;
    }

    public String createRandomPassword() {
        return null;
    }

    public Result pickQuestion(int questionNumber, String answer, String answerConfirmation) {
        return null;
    }

    public Result enterMenu(String menuName) {
        return null;
    }

    public Result exitMenu() {
        return null;
    }
}