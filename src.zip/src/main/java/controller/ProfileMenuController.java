package controller;

import model.Result;

import javax.swing.text.html.HTML;

public class ProfileMenuController {
    public Result enterMenu(String menuName) {
        return null;
    }
    public Result changeUsername(String newUsername) {
        return null;
    }
    public Result changeNickname(String newNickname) {
        return null;
    }
    public Result changePassword(String currentPassword, String newPassword) {
        return null;
    }
    public Result changeEmail(String newEmail) {
        return null;
    }
    public Result showGameHistory(String number){
        return null;
    }

    public Result exitMenu() {
        return null;
    }
}