package controller;

import model.Result;

public class MainMenuController {
    public Result logout() {
        return null;
    }

    public Result enterMenu(String menuName) {
        return null;
    }

    public Result exitMenu() {
        return null;
    }
}