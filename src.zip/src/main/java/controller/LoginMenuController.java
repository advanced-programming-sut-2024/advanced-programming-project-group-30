package controller;

import model.Result;

public class LoginMenuController {
    public Result login(String username, String password, String stayLoggedInTag) {
        return null;
    }

    public Result checkUsernameForForgetPassword(String username) {
        return null;
    }

    public Result checkAnswerOfSecurityQuestion(String username, int questionNumber, String answer) {
        return null;
    }

    public Result changePassword(String username, String password) {
        return null;
    }

    public Result enterMenu(String menuName) {
        return null;
    }

    public Result exitMenu() {
        return null;
    }
}