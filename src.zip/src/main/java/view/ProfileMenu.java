package view;

import java.util.Scanner;

public class ProfileMenu implements Menu{
    public void run(Scanner scanner){
    }
}
