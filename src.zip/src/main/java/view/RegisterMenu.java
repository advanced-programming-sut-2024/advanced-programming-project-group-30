package view;

import java.util.Scanner;

public class RegisterMenu implements Menu{
    public void run(Scanner scanner){
    }
}
