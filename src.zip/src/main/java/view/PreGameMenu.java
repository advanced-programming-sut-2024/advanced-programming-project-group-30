package view;

import java.util.Scanner;

public class PreGameMenu implements Menu{
    public void run(Scanner scanner){
    }
}
