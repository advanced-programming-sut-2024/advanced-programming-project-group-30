package view;

import java.util.Scanner;

public class GameMenu implements Menu{
    public void run(Scanner scanner){
    }
}
