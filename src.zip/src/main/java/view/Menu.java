package view;

import java.util.Scanner;

public interface Menu {
    public void run(Scanner scanner);
}
