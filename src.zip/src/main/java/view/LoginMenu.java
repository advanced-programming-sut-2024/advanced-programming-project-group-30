package view;

import java.util.Scanner;

public class LoginMenu implements Menu{
    public void run(Scanner scanner){
    }
}
