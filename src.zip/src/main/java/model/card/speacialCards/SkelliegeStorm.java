
package model.card.speacialCards;

import model.Faction;
import model.Game;

public class SkelliegeStorm extends SpecialCard {
    public SkelliegeStorm(String name, String explanation, Faction faction) {
        super(name, explanation, faction, false);
    }

    public void run(Game game){
    }
}
