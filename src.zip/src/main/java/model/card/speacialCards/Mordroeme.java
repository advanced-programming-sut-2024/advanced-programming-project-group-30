package model.card.speacialCards;

import model.Faction;
import model.Game;
import model.Row;

public class Mordroeme extends SpecialCard {
    public Mordroeme(String name, String explanation, Faction faction) {
        super(name, explanation, faction, false);
    }

    public void run(Row row, Game game) {
    }
}