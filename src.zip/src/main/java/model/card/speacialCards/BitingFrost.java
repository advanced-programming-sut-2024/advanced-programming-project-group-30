package model.card.speacialCards;

import model.Faction;
import model.Game;

public class BitingFrost extends SpecialCard {
    public BitingFrost(String name, String explanation, Faction faction) {
        super(name, explanation, faction, false);
    }

    public void run(Game game) {
    }
}