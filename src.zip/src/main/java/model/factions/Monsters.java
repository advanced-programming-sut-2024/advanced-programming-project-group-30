package model.factions;

public class Monsters extends Faction{
}
