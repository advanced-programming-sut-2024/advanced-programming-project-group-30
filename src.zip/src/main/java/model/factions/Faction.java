package model.factions;

public abstract class Faction {
}
