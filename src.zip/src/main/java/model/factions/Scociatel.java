package model.factions;

public class Scociatel extends Faction{
}
