package model.factions;

public class Skellige extends Faction{
}
