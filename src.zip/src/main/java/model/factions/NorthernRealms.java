package model.factions;

public class NorthernRealms extends Faction{
}
