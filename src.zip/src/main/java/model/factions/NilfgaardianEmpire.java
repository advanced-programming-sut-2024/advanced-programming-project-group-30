package model.factions;

public class NilfgaardianEmpire extends Faction{
}
