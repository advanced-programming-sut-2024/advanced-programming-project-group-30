package view;

import java.util.Scanner;

public class LoginMenu extends Menu{
    @Override
    public void run(){
        System.out.println("Login Menu");
    }

}
