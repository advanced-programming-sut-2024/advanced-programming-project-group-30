package view;

public class LoginMenu implements Menu{
}
