package view;

public class GameMenu implements Menu{
}
