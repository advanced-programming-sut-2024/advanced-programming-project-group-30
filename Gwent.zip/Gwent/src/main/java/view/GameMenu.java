package view;

import java.util.Scanner;

public class GameMenu extends Menu{
    @Override
    public void run(){
        System.out.println("Game Menu");
    }

}
