package view;

import controller.ProfileMenuController;
import controller.UserInformationController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import model.App;
import model.Result;

import java.util.Objects;
import java.util.Scanner;

public class ProfileMenu extends Menu{
    private final UserInformationController userInformationController = new UserInformationController();
    private final ProfileMenuController profileMenuController = new ProfileMenuController(this);
    @FXML
    private Button changePasswordButton, editUsernameButton, editNicknameButton, editEmailButton;
    @FXML
    private PasswordField oldPassword, newPassword;
    @FXML
    private Pane changePasswordPane;
    @FXML
    private TextField usernameTextField, nicknameTextField, emailTextField, gameHistoryCount;
    @FXML
    private Label usernameErrorField, emailErrorField, nicknameErrorField, gameHistoryNumberErrorField;
    @FXML
    private Button setNewUsernameButton, setNewNicknameButton, setNewEmailButton;
    @FXML
    private Button cancelChangingUsernameButton, cancelChangingNicknameButton, cancelChangingEmailButton;
    @FXML
    private Label rank, highestScore, gameCount, wins, losses, draws;
    @FXML
    private VBox editInformationBox;
    @FXML
    private Label newPasswordError;
    @FXML
    private Label passwordConfirmationErrorField;
    @FXML
    private ScrollPane gameHistoryScrollPane;
    @FXML
    private VBox scrollPaneVbox;
    @FXML
    private Text gameHistoryText;

    @Override
    public void run(){

    }
    @FXML
    public void initialize(){
        rank.setText("1");
        highestScore.setText("highest score: 1000");
        gameCount.setText("Games Played: 10");
        wins.setText("Wins: 5");
        losses.setText("Losses: 3");
        draws.setText("Draws: 2");
        gameHistoryCount.setFocusTraversable(false);
        usernameTextField.textProperty().addListener((observableValue, s, t1) -> {
            usernameTextField.setPromptText("Bahar");
            usernameErrorField.setVisible(false);
            if (!editUsernameButton.isVisible()) {
                usernameErrorField.setVisible(true);
                usernameErrorField.setText(userInformationController.checkUsername(usernameTextField.getText()).toString());
            } else usernameErrorField.setText("");
        });
        nicknameTextField.textProperty().addListener((observableValue, s, t1) -> {
            nicknameErrorField.setText(userInformationController.checkNickname(nicknameTextField.getText()).toString());
        });
        emailTextField.textProperty().addListener((observableValue, s, t1) -> {
            emailErrorField.setText(userInformationController.checkEmail(emailTextField.getText()).toString());
        });
        newPassword.textProperty().addListener((observableValue, s, t1) -> {
            newPasswordError.setText(userInformationController.checkPassword(newPassword.getText()).toString());
        });
        gameHistoryScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        gameHistoryScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        addText("Game 1: 1000\n\n\nGame 2: 900\n\n\nGame 3: 800\n\n\nGame 4: 700\n\n\nGame 5: 600\n\n\nGame 6: 500\n\n\nGame 7: 400\n\n\nGame 8: 300\n\n\nGame 9: 200\n\n\nGame 10: 100");
//        for (int i = 0; i < 10; i++) {
//            Text text = new Text("Game " + i + ": 1000\n");
//            text.getStyleClass().add("profileMenu-scrollbar-textArea");
//            scrollPaneVbox.getChildren().add(text);
//        }
//        gameHistoryCount.textProperty().addListener(((observableValue, s, t1) -> {
//            gameHistoryNumberErrorField.setText(profileMenuController.checkGameHistory(gameHistoryCount.getText()).toString());
//        }));


//        Text text = new Text("Game 1: 1000\nGame 2: 900\nGame 3: 800\nGame 4: 700\nGame 5: 600\nGame 6: 500\nGame 7: 400\nGame 8: 300\nGame 9: 200\nGame 10: 100");
//        gameHistory.getChildren().add(text);
//        username.textProperty().addListener((observable) -> {
//            username.setText(App.getLoggedInUser().getUsername());
//        });
        usernameTextField.textProperty().addListener((observable) -> {
            usernameTextField.setPromptText("Bahar");
        });
        //TODO: add listener for prompt texts
//        username.setPromptText(App.getLoggedInUser().getUsername());
//        nickname.setPromptText(App.getLoggedInUser().getNickName());
//        email.setPromptText(App.getLoggedInUser().getEmail());
//        userInfoTabUsername.setText(App.getLoggedInUser().getUsername());
//        userInfoTabNickname.setText(App.getLoggedInUser().getNickName());
//        rank.setText(String.valueOf(App.getLoggedInUser().getRank()));
//        wins.setText(String.valueOf("Wins: " + App.getLoggedInUser().getWins()));
//        losses.setText(String.valueOf("Losses" + App.getLoggedInUser().getLosses()));
//        draws.setText(String.valueOf("Draws" + App.getLoggedInUser().getDraws()));
        //numberOfPlays.setText(String.valueOf(App.getLoggedInUser().getGameHistories().size()));
    }
    public void addText(String textContent) {
        TextFlow textFlow = new TextFlow();
        Text text = new Text(textContent);
        text.getStyleClass().add("profileMenu-scrollbar-textArea");
        textFlow.getChildren().add(text);
        scrollPaneVbox.getChildren().add(textFlow);
    }

    @FXML
    public void editUsername() {
        usernameTextField.setEditable(true);
        setNewUsernameButton.setVisible(true);
        cancelChangingUsernameButton.setVisible(true);
        editUsernameButton.setVisible(false);
        usernameTextField.setPromptText("Enter new username");
    }


    @FXML
    public void editPassword(){
        changePasswordButton.setVisible(false);
        editInformationBox.setVisible(false);
        changePasswordPane.setVisible(true);

    }
    @FXML
    public void editNickname(){
        nicknameTextField.setEditable(true);
        nicknameTextField.setPromptText("Enter new nickname");
        editNicknameButton.setVisible(false);
        setNewNicknameButton.setVisible(true);
        cancelChangingNicknameButton.setVisible(true);
    }
    @FXML
    public void editEmail(){
        emailTextField.setEditable(true);
        emailTextField.setPromptText("Enter new email");
        editEmailButton.setVisible(false);
        setNewEmailButton.setVisible(true);
        cancelChangingEmailButton.setVisible(true);
    }
    @FXML
    public void checkAndSetNewUsername() {
        Result result = userInformationController.checkUsername(usernameTextField.getText());
        if (!result.isSuccessful()){
            usernameErrorField.setText(result.toString());
        } else {
            changeUsername(usernameTextField.getText());
            usernameTextField.setEditable(false);
            setNewUsernameButton.setVisible(false);
            cancelChangingUsernameButton.setVisible(false);
            editUsernameButton.setVisible(true);
        }
    }
    @FXML
    public void checkAndSetNewNickname(){
        Result result = userInformationController.checkNickname(nicknameTextField.getText());
        if (!result.isSuccessful()){
            nicknameErrorField.setText(result.toString());
        } else {
            changeNickname(nicknameTextField.getText());
            nicknameTextField.setEditable(false);
            setNewNicknameButton.setVisible(false);
            cancelChangingNicknameButton.setVisible(false);
            editNicknameButton.setVisible(true);
        }

    }
    @FXML
    public void checkAndSetNewEmail(){
        Result result = userInformationController.checkEmail(emailTextField.getText());
        if (!result.isSuccessful()){
            emailErrorField.setText(result.toString());
        } else {
            changeEmail(emailTextField.getText());
            emailTextField.setEditable(false);
            setNewEmailButton.setVisible(false);
            cancelChangingEmailButton.setVisible(false);
            editEmailButton.setVisible(true);
        }

    }
    @FXML
    public void cancelChangingUsername() {
        setNewUsernameButton.setVisible(false);
        usernameErrorField.setVisible(false);
        cancelChangingUsernameButton.setVisible(false);
        usernameTextField.setEditable(false);
        editUsernameButton.setVisible(true);
        usernameTextField.clear();
    }
    @FXML
    public void cancelChangingEmail(){
        setNewEmailButton.setVisible(false);
        emailTextField.setEditable(false);
        cancelChangingEmailButton.setVisible(false);
        editEmailButton.setVisible(true);
        emailTextField.clear();

    }
    @FXML
    public void cancelChangingNickname(){
        setNewNicknameButton.setVisible(false);
        nicknameTextField.setEditable(false);
        cancelChangingNicknameButton.setVisible(false);
        editNicknameButton.setVisible(true);
        //nicknameTextField.setPromptText(App.getLoggedInUser().getNickName());
    }
    public void changeUsername(String newUsername){
            App.getLoggedInUser().setUsername(newUsername);
    }
    public void changeNickname(String newNickname){
        App.getLoggedInUser().setNickName(newNickname);
    }
    public void changeEmail(String newEmail){
        App.getLoggedInUser().setEmail(newEmail);
    }
    public void changePassword(String newPassword){
        App.getLoggedInUser().setPassword(newPassword);
    }

    @FXML
    public void setNewPassword() {
        Result result = userInformationController.checkPassword(newPassword.getText());
        if (!result.isSuccessful()){
            passwordConfirmationErrorField.setText(result.toString());
        } else {
            changePassword(newPassword.getText());
            changePasswordPane.setVisible(false);
            editInformationBox.setVisible(true);
            changePasswordButton.setVisible(true);
        }
    }
    @FXML
    public void backToEditInformation(){
        editInformationBox.setVisible(true);
        changePasswordButton.setVisible(true);
        changePasswordPane.setVisible(false);
    }
}
