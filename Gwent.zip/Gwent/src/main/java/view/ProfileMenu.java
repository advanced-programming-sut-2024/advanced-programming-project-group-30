package view;

public class ProfileMenu implements Menu{
}
