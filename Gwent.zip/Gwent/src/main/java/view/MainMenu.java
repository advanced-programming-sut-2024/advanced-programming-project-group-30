package view;

public class MainMenu implements Menu{
}
