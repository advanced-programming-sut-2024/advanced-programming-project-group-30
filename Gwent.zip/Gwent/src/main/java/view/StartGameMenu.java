package view;

public class StartGameMenu implements Menu{
}
