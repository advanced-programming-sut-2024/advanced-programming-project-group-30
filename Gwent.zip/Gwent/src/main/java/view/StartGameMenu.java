package view;

import java.util.Scanner;

public class StartGameMenu extends Menu{
    @Override
    public void run(){
        System.out.println("Start Game Menu");
    }
    
}
