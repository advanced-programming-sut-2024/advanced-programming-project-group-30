package view;

import javafx.fxml.FXML;
import javafx.scene.Scene;

import java.util.Scanner;

public abstract class Menu {
    public abstract void run();
}
