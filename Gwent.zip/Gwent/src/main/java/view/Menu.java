package view;

public interface Menu {
}
