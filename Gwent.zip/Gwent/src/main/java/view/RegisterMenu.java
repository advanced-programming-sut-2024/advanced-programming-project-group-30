package view;

import java.util.Scanner;

public class RegisterMenu extends Menu{
    @Override
    public void run(){
        System.out.println("Register Menu");
    }

}
