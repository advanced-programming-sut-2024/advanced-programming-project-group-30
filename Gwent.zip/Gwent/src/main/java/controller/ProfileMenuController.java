package controller;

public class ProfileMenuController extends Controller{
}
