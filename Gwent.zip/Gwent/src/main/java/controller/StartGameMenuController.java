package controller;

public class StartGameMenuController extends Controller{
}
