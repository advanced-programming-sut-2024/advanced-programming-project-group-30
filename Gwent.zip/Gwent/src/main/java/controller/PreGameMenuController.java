package controller;

import model.Result;

public class PreGameMenuController {
    public Result createGame(String username) {
        return null;
    }

    public Result showFaction() {
        return null;
    }

    public Result selectFaction(String faction) {
        return null;
    }

    public Result showCards() {
        return null;
    }

    public Result showDeck() {
        return null;
    }

    public Result showInformation() {
        return null;
    }

    public Result saveDeckWithName(String deckName) {
        return null;
    }

    public Result saveDeckInFile(String fileName) {
        return null;
    }

    public Result showLeaders() {
        return null;
    }

    public Result selectLeader(String leader) {
        return null;
    }

    public Result addCardToDeck(String cardName, String cardCount) {
        return null;
    }

    public Result deleteCardFromDeck(String cardName, String cardCount) {
        return null;
    }

    public Result changeTurn() {
        return null;
    }

    public Result startGame() {
        return null;
    }

    public Result enterMenu(String menuName) {
        return null;
    }

    public Result exitMenu() {
        return null;
    }
}
