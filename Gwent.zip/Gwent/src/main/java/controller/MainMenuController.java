package controller;

public class MainMenuController extends Controller{
}
