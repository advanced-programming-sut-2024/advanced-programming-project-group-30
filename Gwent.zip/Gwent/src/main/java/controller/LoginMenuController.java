package controller;

public class LoginMenuController extends Controller{
}
