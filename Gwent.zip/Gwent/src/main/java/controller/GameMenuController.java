package controller;

public class GameMenuController extends Controller{
}
