package enums;

public enum StartGameMenuCommands {
}
