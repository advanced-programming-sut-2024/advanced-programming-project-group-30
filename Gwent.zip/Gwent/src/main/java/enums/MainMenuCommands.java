package enums;

public enum MainMenuCommands {
}
