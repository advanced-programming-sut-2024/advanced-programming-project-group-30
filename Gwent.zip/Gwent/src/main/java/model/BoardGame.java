package model;

public class BoardGame {
}
