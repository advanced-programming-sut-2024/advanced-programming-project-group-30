package model;

public class Game {
}
