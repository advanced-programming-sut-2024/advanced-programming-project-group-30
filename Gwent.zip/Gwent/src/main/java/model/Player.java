package model;

public class Player {
}
