package model.card.specialcard;

import model.Faction;
import model.Game;

public class TorrentialRain extends SpecialCard {
    public TorrentialRain(String name, String explanation, Faction faction) {
        super(name, explanation, faction, false);
    }

    public void run(Game game){
    }
}
