package model.card.specialcard;

import model.Faction;
import model.Game;
import model.Row;

public class Scorch extends SpecialCard {
    public Scorch(String name, String explanation, Faction faction) {
        super(name, explanation, faction, true);
    }

    public void run(Row row, Game game) {
    }
}
