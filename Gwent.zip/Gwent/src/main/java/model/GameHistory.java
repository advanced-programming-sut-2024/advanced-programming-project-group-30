package model;

public class GameHistory {
}
